from django.http import HttpResponse
from book.models import Book
from django.db.models import Max,Avg,F,Q
def index(request):
    # book = Book(name='水浒传', author='施耐庵', price=200)
    #book = Book(name='红楼梦', author='曹雪芹', price=100)
    # book.save()
    # Book.objects.all().update(price=F("price") + 30)
    Book.objects.all().aggregate(Avg("price"))
    return HttpResponse("成功了,haha")
